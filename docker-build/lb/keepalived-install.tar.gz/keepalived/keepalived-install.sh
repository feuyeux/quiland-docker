#!/bin/sh

set -x
set -e

nowdir=$(cd "$(dirname "$0")"; pwd)

cd "$nowdir"

keepalived_path=keepalived-1.2.19

echo "========================================================================"
echo "clearing target dir..."

if [ -d "$keepalived_path" ]; then
	rm -rf "$keepalived_path"
fi

echo "========================================================================"
echo "unzip files..."

tar -xf keepalived-1.2.19.tar.gz

echo "========================================================================"
echo "installing dependence..."

echo "========================================================================"
echo "configure install param..."

cd keepalived-1.2.19
./configure --prefix=/usr/local/webserver/keepalived

echo "========================================================================"
echo "installing..."
make && make install

#ִ��������������ʹKeepalived������Ч
cp /usr/local/webserver/keepalived/sbin/keepalived /usr/sbin/
cp /usr/local/webserver/keepalived/etc/sysconfig/keepalived /etc/sysconfig/
cp /usr/local/webserver/keepalived/etc/rc.d/init.d/keepalived /etc/init.d/

if [ ! -d "/etc/keepalived" ]; then
	mkdir /etc/keepalived
fi

cp -f /usr/local/webserver/keepalived/etc/keepalived/keepalived.conf /etc/keepalived
cp -f "$nowdir"/check_nginx.sh /etc/keepalived