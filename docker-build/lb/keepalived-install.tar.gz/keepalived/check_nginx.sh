#!/bin/bash
netstat -antp|grep nginx

if [ $? -ne 0 ]
then
   echo "error"
   exit $?;
fi

exit $?

