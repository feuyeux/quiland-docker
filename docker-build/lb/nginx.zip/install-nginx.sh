#!/bin/sh

set -x
set -e

nowdir=$(cd "$(dirname "$0")"; pwd)

cd "$nowdir"

nginx_path=nginx-1.8.0
sticky_module_path=nginx-goodies-nginx-sticky-module-ng-c78b7dd79d0d

echo "========================================================================"
echo "clearing target dir..."

if [ -d "$nginx_path" ]; then
	rm -rf "$nginx_path"
fi

if [ -d "$sticky_module_path" ]; then
	rm -rf "$sticky_module_path"
fi

echo "========================================================================"
echo "unzip files..."

tar -xf nginx-1.8.0.tar.gz
tar -xf nginx-goodies-nginx-sticky-module-ng.tar.gz

echo "========================================================================"
echo "installing dependence..."

yum -y install gcc
yum -y install pcre-devel
yum -y install zlib-devel
yum -y install openssl-devel
yum -y install popt-devel

echo "========================================================================"
echo "configure install param..."

cd "$nginx_path"

./configure --prefix=/usr/local/nginx-1.8.0 --add-module=../nginx-goodies-nginx-sticky-module-ng-c78b7dd79d0d --sbin-path=/usr/local/nginx/nginx --conf-path=/etc/nginx/nginx.conf --pid-path=/usr/local/nginx/nginx.pid --with-http_ssl_module
make
make install

chmod +x "$nowdir"/nginx 
cp "$nowdir"/nginx /etc/init.d


echo "========================================================================"
echo "Success !"
echo "========================================================================"